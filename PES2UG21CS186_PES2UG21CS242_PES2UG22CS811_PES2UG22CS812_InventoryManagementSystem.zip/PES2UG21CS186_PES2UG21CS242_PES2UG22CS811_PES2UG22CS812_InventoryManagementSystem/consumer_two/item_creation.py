import json
import time

import pika
from pymongo import MongoClient

# MongoDB connection parameters
MONGODB_HOST = "host.docker.internal"
MONGODB_PORT = 27017
MONGODB_DATABASE = "inventory_db"
MONGODB_COLLECTION = "inventory"

# RabbitMQ connection parameters
RABBITMQ_HOST = "rabbitmq"
RABBITMQ_PORT = 5672
RABBITMQ_CREATE_ITEM_QUEUE = "create_item_queue"

# Connect to RabbitMQ
connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST, port=RABBITMQ_PORT))
channel = connection.channel()
channel.queue_declare(queue=RABBITMQ_CREATE_ITEM_QUEUE, durable=True)

def insert_into_mongodb(data):
    try:
        # Connect to MongoDB
        client = MongoClient(f"mongodb://{MONGODB_HOST}:{MONGODB_PORT}/")
        db = client[MONGODB_DATABASE]
        # Insert data into MongoDB collection
        collection = db[MONGODB_COLLECTION]
        collection.insert_one(data)
        print("Data inserted into MongoDB successfully")
    except Exception as e:
        print("Failed to insert data into MongoDB:", str(e))

# Define callback function to handle incoming messages
def callback(ch, method, properties, body):
    
    message = json.loads(body.decode("utf-8"))
    record = message['data']
    print(record)
    
    # Check if the message is for item creation
    if "action" in message and message["action"] == "create_item":
        # Insert the data into MongoDB
        insert_into_mongodb(record)
        ch.basic_ack(delivery_tag=method.delivery_tag)
        
# Consume messages from the queue
channel.basic_consume(queue=RABBITMQ_CREATE_ITEM_QUEUE, on_message_callback=callback)

print('Waiting for create item messages...')
channel.start_consuming()

    
