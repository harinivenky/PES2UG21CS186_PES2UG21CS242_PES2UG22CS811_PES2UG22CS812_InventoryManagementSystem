import time

import pika
from pymongo import MongoClient

# MongoDB connection parameters
MONGODB_HOST = "host.docker.internal"
MONGODB_PORT = 27017
MONGODB_DATABASE = "inventory_db"

# RabbitMQ connection parameters
RABBITMQ_HOST = "rabbitmq"
RABBITMQ_PORT = 5672
RABBITMQ_USER = 'guest'
RABBITMQ_PWD = 'guest'
RABBITMQ_HEALTHCHECK_QUEUE = "healthcheck_queue"

# Callback function
def callback(ch, method, properties, body):
    print(" [x] Received %r" % body)
    time.sleep(body.count(b'.'))
    print(" [x] Done")
    ch.basic_ack(delivery_tag = method.delivery_tag)

# Check MongoDB Connection
try:
    # Connect to MongoDB
    client = MongoClient(f"mongodb://{MONGODB_HOST}:{MONGODB_PORT}/")
    db = client[MONGODB_DATABASE]
    # Check if the connection is successful by listing collections
    collections = db.list_collection_names()
    print("MongoDB Connection Successful. Collections:", collections)
except Exception as e:
    print("MongoDB Connection Failed. Error:", str(e))

# RabbitMQ setup

#credentials = pika.PlainCredentials(username=RABBITMQ_USER, password=RABBITMQ_PWD)
parameters = pika.ConnectionParameters(host=RABBITMQ_HOST, port=RABBITMQ_PORT)
connection = pika.BlockingConnection(parameters=parameters)
channel = connection.channel()
channel.queue_declare(queue=RABBITMQ_HEALTHCHECK_QUEUE, durable=True)
    
print(' [*] Waiting for messages. To exit press CTRL+C')
# Consume the queue
channel.basic_consume(queue=RABBITMQ_HEALTHCHECK_QUEUE, on_message_callback=callback)
channel.start_consuming()