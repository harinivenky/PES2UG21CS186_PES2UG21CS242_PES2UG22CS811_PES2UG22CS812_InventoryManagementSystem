import json
import time

import pika
from flask import (Flask, flash, jsonify, redirect, render_template, request,
                   url_for)

app = Flask(__name__, template_folder='templates')
app.config['SECRET_KEY'] = 'secret'

# RabbitMQ connection parameters
RABBITMQ_HOST = "rabbitmq"
RABBITMQ_PORT = 5672
RABBITMQ_USER = 'guest'
RABBITMQ_PWD = 'guest'
RABBITMQ_HEALTHCHECK_QUEUE = "healthcheck_queue"
RABBITMQ_CREATE_ITEM_QUEUE = "create_item_queue"
RABBITMQ_DELETE_ITEM_QUEUE = "delete_item_queue"
RABBITMQ_REQUEST_ORDER_QUEUE = "request_order_queue"
RABBITMQ_SEND_ORDER_QUEUE = "send_order_queue"

connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST, port=RABBITMQ_PORT))
channel = connection.channel()
        
# Declare the queues
channel.queue_declare(queue=RABBITMQ_HEALTHCHECK_QUEUE, durable=True)
channel.queue_declare(queue=RABBITMQ_CREATE_ITEM_QUEUE, durable=True)
channel.queue_declare(queue=RABBITMQ_DELETE_ITEM_QUEUE, durable=True)
channel.queue_declare(queue=RABBITMQ_REQUEST_ORDER_QUEUE, durable=True)
channel.queue_declare(queue=RABBITMQ_SEND_ORDER_QUEUE, durable=True)
      
@app.route("/")
def index():
    return render_template('index.html')

@app.route("/health_check", methods=["GET"])
def health_check():
    message = {"status": "health_check"}
    msg_props = pika.BasicProperties(content_type='application/json', content_encoding='utf-8',
                                     headers={'key': 'value'}, delivery_mode = 1)
    channel.basic_publish(
        exchange='', routing_key=RABBITMQ_HEALTHCHECK_QUEUE, body=json.dumps(message),
        properties = msg_props)
    flash('Health Check Message sent to RabbitMQ')
    return redirect(url_for('index'))

@app.route("/create_item", methods=["GET"])
def create_item():
    return render_template('create_item.html') 

# Insert record endpoint
@app.route('/insert_record_actually', methods=['POST'])
def insert_record_actually():
    prod_id = request.form['Product ID']
    name = request.form['Product Name']
    qty = request.form['Quantity']
    price = request.form['Price']
    desc = request.form['Description']
    data = {'Product ID': prod_id, 'Name': name, 'Quantity': qty,
                        'Price:': price, 'Description': desc}
    message = {"action": "create_item", "data": data}
    print("Data is :\n",data)
    print("Message is :\n",message)
   
    msg_props = pika.BasicProperties(content_type='application/json', content_encoding='utf-8',
                                     headers={'key': 'value'}, delivery_mode = 1)
    
    channel.basic_publish(
        exchange='', routing_key=RABBITMQ_CREATE_ITEM_QUEUE, body=json.dumps(message),
        properties = msg_props)
    print("Create request sent to RabbitMQ")
    return render_template('create_item.html')

@app.route("/create_item/back")
def create_item_back():
    return redirect(url_for('index'))

@app.route("/stock_mgmt", methods=["GET"])
def stock_mgmt():
    return render_template('delete.html') 

@app.route('/delete_record_actually', methods=['POST'])
def delete_record_actually():
    prod_id = request.form['prod_id']
    data = {'Product ID': prod_id}
    message = {"action": "delete_item", "data": data}
    msg_props = pika.BasicProperties(content_type='application/json', content_encoding='utf-8',
                                     headers={'key': 'value'}, delivery_mode = 1)
    channel.basic_publish(
        exchange='', routing_key=RABBITMQ_DELETE_ITEM_QUEUE, body=json.dumps(message),
        properties = msg_props)
    print("Delete request sent to RabbitMQ")
    return render_template('delete.html')

@app.route("/stock_mgmt/back")
def stock_mgmt_back():
    return redirect(url_for('index'))

@app.route("/order_proc", methods=["GET"])
def read_items():
    message = {"status": "Order Processing"}
    msg_props = pika.BasicProperties(content_type='application/json', content_encoding='utf-8',
                                     headers={'key': 'value'}, delivery_mode = 1)
    channel.basic_publish(
        exchange='', routing_key=RABBITMQ_REQUEST_ORDER_QUEUE, body=json.dumps(message),
        properties = msg_props)
    return render_template('read.html')

@app.route('/read_database_actually', methods=['GET'])
def read_database_actually():
    method_frame, header_frame, body = channel.basic_get(queue=RABBITMQ_SEND_ORDER_QUEUE)
    channel.basic_ack(delivery_tag=method_frame.delivery_tag)
    print("Method Frame : ",method_frame)
    print("Body is : ",body.decode('utf-8'))
    if method_frame:
        records = body.decode('utf-8')
    else:
        records = {}

    return records
    
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
