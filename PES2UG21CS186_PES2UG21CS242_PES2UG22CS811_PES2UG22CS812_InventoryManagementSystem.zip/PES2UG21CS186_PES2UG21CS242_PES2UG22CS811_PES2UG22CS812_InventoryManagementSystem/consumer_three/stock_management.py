import json

import pika
from pymongo import MongoClient

# MongoDB connection parameters
MONGODB_HOST = "host.docker.internal"
MONGODB_PORT = 27017
MONGODB_DATABASE = "inventory_db"
MONGODB_COLLECTION = "inventory"

# RabbitMQ connection parameters
RABBITMQ_HOST = "rabbitmq"
RABBITMQ_PORT = 5672
RABBITMQ_DELETE_ITEM_QUEUE = "delete_item_queue"

# Connect to RabbitMQ
connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST, port=RABBITMQ_PORT))
channel = connection.channel()
channel.queue_declare(queue=RABBITMQ_DELETE_ITEM_QUEUE, durable=True)

def delete_document_in_mongodb(data):
        # Connect to MongoDB
        client = MongoClient(f"mongodb://{MONGODB_HOST}:{MONGODB_PORT}/")
        db = client[MONGODB_DATABASE]

        # Delete the document in MongoDB
        db[MONGODB_COLLECTION].delete_one(data)

        print(f"Document updated for product ID {data['Product ID']}")


# Define callback function to handle incoming messages
def callback(ch, method, properties, body):
    message = json.loads(body.decode("utf-8"))
    record = message['data']
    print("Received message:", message)

    # Check if the message id for item deletion
    if "action" in message and message["action"] == "delete_item":
        # Delete the document in MongoDB
        delete_document_in_mongodb(record)
        ch.basic_ack(delivery_tag=method.delivery_tag)
        
# Consume messages from the queue
channel.basic_consume(queue=RABBITMQ_DELETE_ITEM_QUEUE, on_message_callback=callback)

print("Waiting for delete messages...")
channel.start_consuming()