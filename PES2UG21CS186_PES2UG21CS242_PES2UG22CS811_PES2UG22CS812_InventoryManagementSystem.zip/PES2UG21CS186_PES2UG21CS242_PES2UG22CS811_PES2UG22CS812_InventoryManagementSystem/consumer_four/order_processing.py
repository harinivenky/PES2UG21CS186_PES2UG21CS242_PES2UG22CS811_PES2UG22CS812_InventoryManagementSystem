# print("Performing order_processing")
import pika
import json
from pymongo import MongoClient
from bson.json_util import dumps

# MongoDB connection parameters
MONGODB_HOST = "host.docker.internal"
MONGODB_PORT = 27017
MONGODB_DATABASE = "inventory_db"
MONGODB_COLLECTION = "inventory"

# RabbitMQ connection parameters
RABBITMQ_HOST = "rabbitmq"
RABBITMQ_PORT = 5672
RABBITMQ_REQUEST_ORDER_QUEUE = "request_order_queue"
RABBITMQ_SEND_ORDER_QUEUE = "send_order_queue"

# Connect to RabbitMQ
connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST, port=RABBITMQ_PORT))
channel = connection.channel()
channel.queue_declare(queue=RABBITMQ_REQUEST_ORDER_QUEUE, durable=True)
channel.queue_declare(queue=RABBITMQ_SEND_ORDER_QUEUE, durable=True)

def read_all_documents_from_mongodb():
    try:
        # Connect to MongoDB
        client = MongoClient(f"mongodb://{MONGODB_HOST}:{MONGODB_PORT}/")
        db = client[MONGODB_DATABASE]
        
        # Retrieve all documents from MongoDB
        documents = db[MONGODB_COLLECTION].find()
        list_docs = list(documents)
    except Exception as e:
        print("Error reading documents from MongoDB:", str(e))
        list_docs = {}
    msg_props = pika.BasicProperties(content_type='application/json', content_encoding='utf-8',
                                  headers={'key': 'value'}, delivery_mode = 1)
    channel.basic_publish(exchange='', routing_key=RABBITMQ_SEND_ORDER_QUEUE, body=dumps(list_docs),
                                properties = msg_props)

# Define callback function to handle incoming messages
def callback(ch, method, properties, body):
    print(" [x] Received request to fetch all product details ")
    read_all_documents_from_mongodb()
    ch.basic_ack(delivery_tag = method.delivery_tag)

# Consume messages from the queue
channel.basic_consume(queue=RABBITMQ_REQUEST_ORDER_QUEUE, on_message_callback=callback)

print("Waiting for product list messages...")
channel.start_consuming()
